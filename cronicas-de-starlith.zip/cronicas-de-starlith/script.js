(() => {
  "use strict";
  const STORAGE_KEY = "cronicas-starlith-save-v1";
  const RARITIES = [
    { name: "Comum", key: "comum", weight: 55, className: "comum" },
    { name: "Rara", key: "rara", weight: 25, className: "rara" },
    { name: "Épica", key: "epica", weight: 12, className: "epica" },
    { name: "Lendária", key: "lendaria", weight: 6, className: "lendaria" },
    { name: "Mítica", key: "mitica", weight: 1.8, className: "mitica" },
    { name: "Starlith", key: "starlith", weight: 0.2, className: "starlith" }
  ];
  const PACKS = {
    forest: { name: "Ecos da Floresta", cards: ["lyra","brom","silvan","moss","fael","thorn"] },
    abyss: { name: "Chamado do Abismo", cards: ["nyx","leviathan","mora","kelp","abyssal","nereid"] },
    celestial: { name: "Trono Celestial", cards: ["aureon","solara","ignis","seraph","astrid","orion"] }
  };
  const CARDS = [
    {id:"lyra",name:"Lyra, Arqueira Verdejante",symbol:"🏹",element:"FLORESTA",rarity:"Comum",power:12,pack:"forest"},
    {id:"brom",name:"Brom, Ferreiro de Runas",symbol:"⚒️",element:"MONTANHA",rarity:"Comum",power:15,pack:"forest"},
    {id:"silvan",name:"Silvan, Guardião Antigo",symbol:"🌳",element:"FLORESTA",rarity:"Rara",power:28,pack:"forest"},
    {id:"moss",name:"Moss, Espírito Musgoso",symbol:"🍃",element:"NATUREZA",rarity:"Comum",power:10,pack:"forest"},
    {id:"fael",name:"Fael, Príncipe Élfico",symbol:"🧝",element:"FLORESTA",rarity:"Épica",power:46,pack:"forest"},
    {id:"thorn",name:"Thorn, Rei dos Espinhos",symbol:"🌿",element:"FLORESTA",rarity:"Lendária",power:75,pack:"forest"},
    {id:"nyx",name:"Nyx, Oráculo Profundo",symbol:"🔮",element:"ABISMO",rarity:"Rara",power:30,pack:"abyss"},
    {id:"leviathan",name:"Leviatã das Marés Negras",symbol:"🐉",element:"OCEANO",rarity:"Lendária",power:82,pack:"abyss"},
    {id:"mora",name:"Mora, Bruxa das Fossas",symbol:"🧙",element:"ABISMO",rarity:"Épica",power:50,pack:"abyss"},
    {id:"kelp",name:"Kelp, Vigia das Profundezas",symbol:"🪸",element:"OCEANO",rarity:"Comum",power:14,pack:"abyss"},
    {id:"abyssal",name:"Devorador Abissal",symbol:"🦑",element:"ABISMO",rarity:"Rara",power:32,pack:"abyss"},
    {id:"nereid",name:"Nereida, Voz do Mar",symbol:"🧜",element:"OCEANO",rarity:"Mítica",power:95,pack:"abyss"},
    {id:"aureon",name:"Aureon, Dragão Solar",symbol:"🐲",element:"CÉU",rarity:"Mítica",power:98,pack:"celestial"},
    {id:"solara",name:"Solara, Fênix Dourada",symbol:"🔥",element:"LUZ",rarity:"Épica",power:53,pack:"celestial"},
    {id:"ignis",name:"Ignis, Filhote de Brasa",symbol:"🐉",element:"FOGO",rarity:"Comum",power:18,pack:"celestial"},
    {id:"seraph",name:"Seraph, Arauto das Estrelas",symbol:"🪽",element:"CÉU",rarity:"Lendária",power:80,pack:"celestial"},
    {id:"astrid",name:"Astrid, Maga Celeste",symbol:"✨",element:"ASTRAL",rarity:"Rara",power:34,pack:"celestial"},
    {id:"orion",name:"Orion, Dragão Starlith",symbol:"🌌",element:"STARLITH",rarity:"Starlith",power:120,pack:"celestial"}
  ];
  let state = loadState();
  let pendingCards = [];
  let toastTimer;

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const rarityFor = (name) => RARITIES.find(r => r.name === name) || RARITIES[0];
  const rarityClass = (name) => rarityFor(name).className;
  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (saved && saved.collection && Number.isFinite(saved.dust)) return saved;
    } catch (_) {}
    return { dust: 250, collection: {}, totalPulled: 0 };
  }
  function saveState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
    catch (_) { showToast("Não foi possível salvar. Verifique o espaço disponível no navegador."); }
    updateStats();
  }
  function updateStats() {
    const unique = Object.keys(state.collection).length;
    const total = Object.values(state.collection).reduce((sum, qty) => sum + qty, 0);
    $("#dust-count").textContent = state.dust;
    $("#unique-count").textContent = unique;
    $("#total-count").textContent = total;
    $("#starlith-count").textContent = state.collection.orion || 0;
    $("#collection-badge").textContent = unique;
    $("#collection-total").textContent = `${total} carta${total === 1 ? "" : "s"} • ${unique} única${unique === 1 ? "" : "s"}`;
  }
  function weightedRarity() {
    const roll = Math.random() * 100;
    let sum = 0;
    for (const rarity of RARITIES) { sum += rarity.weight; if (roll < sum) return rarity.name; }
    return "Comum";
  }
  function pullCard(packKey) {
    const pack = PACKS[packKey];
    let rarity = weightedRarity();
    // Cada pack tem cartas disponíveis em diferentes raridades; use um personagem que corresponda à raridade sorteada.
    let pool = pack.cards.map(id => CARDS.find(card => card.id === id)).filter(Boolean);
    let matching = pool.filter(card => card.rarity === rarity);
    if (rarity === "Starlith") matching = [CARDS.find(card => card.id === "orion")];
    if (!matching.length) {
      const allMatching = CARDS.filter(card => card.rarity === rarity);
      matching = allMatching.length ? allMatching : pool.filter(card => card.rarity === "Comum");
    }
    const card = matching[Math.floor(Math.random() * matching.length)] || pool[0];
    // A raridade sorteada é a da carta revelada, garantindo que o visual combine com a raridade anunciada.
    return {...card, rarity, instanceId: `${Date.now()}-${Math.random().toString(16).slice(2)}`};
  }
  function cardMarkup(card, reveal = false, index = 0) {
    const cls = rarityClass(card.rarity);
    const qty = state.collection[card.id] || 0;
    return `<article class="${reveal ? "reveal-card" : "card-tile"}" style="--delay:${index * 0.09}s" ${reveal ? "" : `data-card="${card.id}"`}>
      ${!reveal && qty > 1 ? `<span class="qty">×${qty}</span>` : ""}
      <div class="card-face ${cls}">
        <div class="card-art">
          <span class="element">${escapeHtml(card.element)}</span>
          <span class="symbol">${card.symbol}</span>
          <span class="power">${card.power}</span>
        </div>
      </div>
      <h4>${escapeHtml(card.name)}</h4><p class="rarity-label">${escapeHtml(card.rarity)}</p>
    </article>`;
  }
  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[char]));
  }
  function openPack(packKey) {
    if (!PACKS[packKey]) return;
    if (state.dust < 100) { showToast("Essências insuficientes! Você recebe 250 para começar."); return; }
    state.dust -= 100;
    pendingCards = Array.from({length:5}, () => pullCard(packKey));
    $("#reveal-title").textContent = PACKS[packKey].name;
    $("#reveal-subtitle").textContent = "Toque nas cartas para admirar suas descobertas.";
    $("#revealed-cards").innerHTML = pendingCards.map((card, i) => cardMarkup(card, true, i)).join("");
    $("#reveal-modal").classList.remove("hidden");
    document.body.style.overflow = "hidden";
    saveState();
    const special = pendingCards.some(card => ["Mítica","Starlith"].includes(card.rarity));
    if (special) showToast(pendingCards.some(card => card.rarity === "Starlith") ? "✦ STARLITH DESCOBERTA! Uma carta cósmica!" : "Uma descoberta extraordinária apareceu!");
  }
  function claimCards() {
    if (!pendingCards.length) { closeModal(); return; }
    pendingCards.forEach(card => {
      state.collection[card.id] = (state.collection[card.id] || 0) + 1;
      state.totalPulled += 1;
    });
    saveState();
    pendingCards = [];
    closeModal();
    renderCollection();
    showToast("Cartas guardadas no seu grimório!");
  }
  function closeModal() { $("#reveal-modal").classList.add("hidden"); document.body.style.overflow = ""; }
  function renderCollection() {
    const query = $("#search-cards").value.trim().toLocaleLowerCase("pt-BR");
    const rarity = $("#filter-rarity").value;
    const found = CARDS.filter(card => state.collection[card.id] && (rarity === "all" || card.rarity === rarity) && card.name.toLocaleLowerCase("pt-BR").includes(query));
    $("#collection-grid").innerHTML = found.map(card => cardMarkup(card)).join("");
    $("#empty-collection").classList.toggle("hidden", found.length > 0);
    if (!found.length && Object.keys(state.collection).length > 0) {
      $("#empty-collection").querySelector("h3").textContent = "Nenhuma carta encontrada";
      $("#empty-collection").querySelector("p").textContent = "Tente outro nome ou filtro de raridade.";
      $("#go-packs").classList.add("hidden");
    } else {
      $("#empty-collection").querySelector("h3").textContent = "Sua lenda começa agora";
      $("#empty-collection").querySelector("p").textContent = "Abra seu primeiro pack para descobrir cartas e preencher seu grimório.";
      $("#go-packs").classList.remove("hidden");
    }
  }
  function showView(view) {
    $$(".tab").forEach(tab => tab.classList.toggle("active", tab.dataset.view === view));
    $("#packs-view").classList.toggle("hidden", view !== "packs");
    $("#collection-view").classList.toggle("hidden", view !== "collection");
    if (view === "collection") renderCollection();
    window.scrollTo({top: 0, behavior: "smooth"});
  }
  function showToast(message) {
    const el = $("#toast");
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove("show"), 3000);
  }
  $$(".tab").forEach(tab => tab.addEventListener("click", () => showView(tab.dataset.view)));
  $$(".open-pack").forEach(button => button.addEventListener("click", () => openPack(button.dataset.pack)));
  $("#claim-cards").addEventListener("click", claimCards);
  $("#close-modal").addEventListener("click", () => { if (pendingCards.length) showToast("Guarde suas cartas antes de fechar."); else closeModal(); });
  $("#reveal-modal").addEventListener("click", event => { if (event.target.classList.contains("modal-backdrop")) showToast("Toque em “Guardar na coleção” para salvar suas cartas."); });
  $("#search-cards").addEventListener("input", renderCollection);
  $("#filter-rarity").addEventListener("change", renderCollection);
  $("#go-packs").addEventListener("click", () => showView("packs"));
  $("#collection-grid").addEventListener("click", event => {
    const tile = event.target.closest("[data-card]");
    if (tile) {
      const card = CARDS.find(item => item.id === tile.dataset.card);
      if (card) showToast(`${card.name} • ${card.rarity} • Poder ${card.power}`);
    }
  });
  updateStats();
})();