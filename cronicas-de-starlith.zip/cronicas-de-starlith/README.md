# Crônicas de Starlith

Protótipo de jogo de cartas colecionáveis feito com HTML, CSS e JavaScript puro, pensado para celular e publicação no GitHub Pages.

## Como publicar pelo celular

1. Entre em https://github.com/ e faça login ou crie uma conta.
2. Toque no botão **+** e escolha **New repository**.
3. Nome do repositório: `cronicas-de-starlith`.
4. Marque **Public**. Se aparecer a opção para adicionar README, pode deixar desmarcada.
5. Crie o repositório.
6. Na página do repositório, escolha **Add file → Upload files**.
7. Envie os três arquivos do projeto: `index.html`, `style.css` e `script.js`. Você também pode enviar `README.md`.
8. Confirme com **Commit changes**.
9. Abra **Settings → Pages**.
10. Em **Build and deployment**, escolha **Deploy from a branch**.
11. Selecione a branch `main` e a pasta `/(root)`, depois toque em **Save**.
12. Aguarde alguns minutos. O endereço será parecido com `https://SEU-USUARIO.github.io/cronicas-de-starlith/`.

## O que já funciona

- Três packs temáticos com cinco cartas por abertura.
- Essências fictícias para testar o sistema.
- Seis níveis de raridade, incluindo Starlith.
- Brilho animado especial para cartas Starlith.
- Coleção, contagem de cartas, busca e filtro por raridade.
- Salvamento local no navegador do dispositivo.

## Notas

- Este é um protótipo: as artes são símbolos e ilustrações tipográficas provisórias, não artes finais originais.
- A coleção fica salva no armazenamento local do navegador. Limpar os dados do navegador pode apagá-la e ela não sincroniza entre dispositivos.
- As probabilidades são de protótipo e podem ser ajustadas no arquivo `script.js`.
- GitHub Pages publica um site estático; login, contas e coleção sincronizada exigiriam um backend adicional.
